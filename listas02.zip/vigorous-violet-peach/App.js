import {View, Text, StatusBar, StyleSheet, SectionList} from 'react-native'

const DATA = [
  {
    titulo: 'Eletronicos',
    data: ['TV', 'Celulares', ' Camera Digital', 'CDs', 'Caixa de som']
  },

  {
    titulo: 'Vestuarios',
    data: ['Camisas', 'Camisetas', 'Calças jeans', 'Bermuda', 'Sapatos']
  },

  {
    titulo: 'Livros',
    data: ['Ficção', 'Suspense', 'Policial', 'Terror', 'Fantasia']
  },
];

const Item = ({titulo})=>(
  <View style = {estilos.item}>
    <Text style = {estilos.titulo}>{titulo}</Text>
  </View>
)

const App = () => (
  <View style = {estilos.janela}>
    <SectionList 
      sections = {DATA}
      keyExtractor = {(item, index) => item + index}
      renderItem = {({item}) => <Item titulo = {item}/>}
      renderSectionHeader = {({section: {titulo}}) => (
        <Text style = {estilos.header}>{titulo}</Text>
      )}
    />
  </View>
)

const estilos = StyleSheet.create({
  janela: {
    flex: 1,
    paddingTop: StatusBar.currentHeight,
    marginHorizontal: 10,
  },

  item:{
    backgroundColor: '#fffccc',
    padding: 10,
    marginVertical: 8
  },

  titulo:{
    fontSize: 18,
  },
  
  header: {
    fontWeight: 'bold',
    textAlign: 'center',
    fontSize: 30,
    backgroundColor: '#ff00cc'
  }
})

export default App